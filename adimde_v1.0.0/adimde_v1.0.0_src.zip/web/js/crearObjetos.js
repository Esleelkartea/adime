function objetoElemento(iModoVisualizacion,viewedRows,strTotalRegistros,strGap, strTableId,strFunction,strTituloLista,strTituloForm,tableContentServlet,strLinkAddServlet,strLinkDeleteServlet,strLinkDuplicarServlet,strLinkEditServlet,strLinkEditParam,strCampos,strTipoEditor,strCamposDec,strCamposWidth,strLinksUlContentServlet,strMetodosController,strLinksUpdateServlet,strEsOrdenable,strEventos,strValidarColumnasGrid,strFormCampos,strFormCamposOblig,strFormTipoEditor,strFormCamposDec,strFormCamposWidth,strFormLinksUlContentServlet,strFormLinksElementServlet,strFormMetodosController,strValidarCamposForm,strFormCabeceraLinks,strFormCabeceraFunctions,strCabeceraLinks,strCabeceraFunctions,strCabeceraIds,strLinkDetallePdfServlet,strLinkDetallePdfServletDec,strLinkListaPdfServlet,strLinkListaPdfServletDec,strFiltroLinks,strFiltroFunctions,strSeparadorFecha,strSeparadorHora)
{
	this.iModoVisualizacion = iModoVisualizacion;
	this.viewedRows = viewedRows;
	this.strTotalRegistros = strTotalRegistros;
	this.strGap = strGap;
	this.strTableId = strTableId;
	this.strFunction = strFunction;
	this.strTituloLista = strTituloLista;
	this.strTituloForm = strTituloForm;
	this.tableContentServlet = tableContentServlet;
	this.strLinkAddServlet = strLinkAddServlet;
	this.strLinkDeleteServlet = strLinkDeleteServlet;
	this.strLinkDuplicarServlet = strLinkDuplicarServlet;
	this.strLinkEditServlet = strLinkEditServlet;
	this.strLinkEditParam = strLinkEditParam;
	
	this.strCampos = strCampos;
	this.strTipoEditor = strTipoEditor;
	this.strCamposDec = strCamposDec;
	this.strCamposWidth = strCamposWidth;
	this.strLinksUlContentServlet = strLinksUlContentServlet;
	this.strMetodosController = strMetodosController;
	this.strLinksUpdateServlet = strLinksUpdateServlet;
	this.strEsOrdenable = strEsOrdenable;
	this.strEventos = strEventos;
	this.strValidarColumnasGrid = strValidarColumnasGrid;
	
	this.strFormCampos = strFormCampos;
	this.strFormCamposOblig = strFormCamposOblig;
	this.strFormTipoEditor = strFormTipoEditor;
	this.strFormCamposDec = strFormCamposDec;
	this.strFormCamposWidth = strFormCamposWidth;
	this.strFormLinksUlContentServlet = strFormLinksUlContentServlet;
	this.strFormLinksElementServlet = strFormLinksElementServlet;
	this.strFormMetodosController = strFormMetodosController;
	this.strValidarCamposForm = strValidarCamposForm;
	
	this.strFormCabeceraLinks = strFormCabeceraLinks;
	this.strFormCabeceraFunctions = strFormCabeceraFunctions;
	this.strCabeceraLinks = strCabeceraLinks;
	this.strCabeceraFunctions = strCabeceraFunctions;
	this.strCabeceraIds = strCabeceraIds;
	this.strLinkDetallePdfServlet = strLinkDetallePdfServlet;
	this.strLinkDetallePdfServletDec = strLinkDetallePdfServletDec;
	this.strLinkListaPdfServlet = strLinkListaPdfServlet;
	this.strLinkListaPdfServletDec = strLinkListaPdfServletDec;
	this.strFiltroLinks = strFiltroLinks;
	this.strFiltroFunctions = strFiltroFunctions;
	this.strSeparadorFecha = strSeparadorFecha;
	this.strSeparadorHora = strSeparadorHora;	
}

function getiModoVisualizacion()
{
	return this.iModoVisualizacion;
}
objetoElemento.prototype.getiModoVisualizacion= getiModoVisualizacion;

function setiModoVisualizacion(str)
{
	this.iModoVisualizacion = str;
}
objetoElemento.prototype.setiModoVisualizacion= setiModoVisualizacion;

function getviewedRows()
{
	return this.viewedRows;
}
objetoElemento.prototype.getviewedRows= getviewedRows;

function setviewedRows(str)
{
	this.viewedRows = str;
}
objetoElemento.prototype.setviewedRows= setviewedRows;

function getstrTotalRegistros()
{
	return this.strTotalRegistros;
}
objetoElemento.prototype.getstrTotalRegistros= getstrTotalRegistros;

function setstrTotalRegistros(str)
{
	this.strTotalRegistros = str;
}
objetoElemento.prototype.setstrTotalRegistros= setstrTotalRegistros;

function getstrGap()
{
	return this.strGap;
}
objetoElemento.prototype.getstrGap= getstrGap;

function setstrGap(str)
{
	this.strGap = str;
}
objetoElemento.prototype.setstrGap= setstrGap;

function getstrTableId()
{
	return this.strTableId;
}
objetoElemento.prototype.getstrTableId= getstrTableId;

function setstrTableId(str)
{
	this.strTableId = str;
}
objetoElemento.prototype.setstrTableId= setstrTableId;

function getstrFunction()
{
	return this.strFunction;
}
objetoElemento.prototype.getstrFunction= getstrFunction;

function setstrFunction(str)
{
	this.strFunction = str;
}
objetoElemento.prototype.setstrFunction= setstrFunction;

function getstrTituloLista()
{
	return this.strTituloLista;
}
objetoElemento.prototype.getstrTituloLista= getstrTituloLista;

function setstrTituloLista(str)
{
	this.strTituloLista = str;
}
objetoElemento.prototype.setstrTituloLista= setstrTituloLista;

function getstrTituloForm()
{
	return this.strTituloForm;
}
objetoElemento.prototype.getstrTituloForm= getstrTituloForm;

function setstrTituloForm(str)
{
	this.strTituloForm = str;
}
objetoElemento.prototype.setstrTituloForm= setstrTituloForm;

function gettableContentServlet()
{
	return this.tableContentServlet;
}
objetoElemento.prototype.gettableContentServlet= gettableContentServlet;

function settableContentServlet(str)
{
	this.tableContentServlet = str;
}
objetoElemento.prototype.settableContentServlet= settableContentServlet;

function getstrLinkAddServlet()
{
	return this.strLinkAddServlet;
}
objetoElemento.prototype.getstrLinkAddServlet= getstrLinkAddServlet;

function setstrLinkAddServlet(str)
{
	this.strLinkAddServlet = str;
}
objetoElemento.prototype.setstrLinkAddServlet= setstrLinkAddServlet;

function getstrLinkDeleteServlet()
{
	return this.strLinkDeleteServlet;
}
objetoElemento.prototype.getstrLinkDeleteServlet= getstrLinkDeleteServlet;

function setstrLinkDeleteServlet(str)
{
	this.strLinkDeleteServlet = str;
}
objetoElemento.prototype.setstrLinkDeleteServlet= setstrLinkDeleteServlet;

function getstrLinkDuplicarServlet()
{
	return this.strLinkDuplicarServlet;
}
objetoElemento.prototype.getstrLinkDuplicarServlet= getstrLinkDuplicarServlet;

function setstrLinkDuplicarServlet(str)
{
	this.strLinkDuplicarServlet = str;
}
objetoElemento.prototype.setstrLinkDuplicarServlet= setstrLinkDuplicarServlet;

function getstrLinkEditServlet()
{
	return this.strLinkEditServlet;
}
objetoElemento.prototype.getstrLinkEditServlet= getstrLinkEditServlet;

function setstrLinkEditServlet(str)
{
	this.strLinkEditServlet = str;
}
objetoElemento.prototype.setstrLinkEditServlet= setstrLinkEditServlet;

function getstrLinkEditParam()
{
	return this.strLinkEditParam;
}
objetoElemento.prototype.getstrLinkEditParam= getstrLinkEditParam;

function setstrLinkEditParam(str)
{
	this.strLinkEditParam = str;
}
objetoElemento.prototype.setstrLinkEditParam= setstrLinkEditParam;


function getstrCampos()
{
	return this.strCampos;
}
objetoElemento.prototype.getstrCampos= getstrCampos;

function setstrCampos(str)
{
	this.strCampos = str;
}
objetoElemento.prototype.setstrCampos= setstrCampos;

function getstrTipoEditor()
{
	return this.strTipoEditor;
}
objetoElemento.prototype.getstrTipoEditor= getstrTipoEditor;

function setstrTipoEditor(str)
{
	this.strTipoEditor = str;
}
objetoElemento.prototype.setstrTipoEditor= setstrTipoEditor;

function getstrCamposDec()
{
	return this.strCamposDec;
}
objetoElemento.prototype.getstrCamposDec= getstrCamposDec;

function setstrCamposDec(str)
{
	this.strCamposDec = str;
}
objetoElemento.prototype.setstrCamposDec= setstrCamposDec;

function getstrCamposWidth()
{
	return this.strCamposWidth;
}
objetoElemento.prototype.getstrCamposWidth= getstrCamposWidth;

function setstrCamposWidth(str)
{
	this.strCamposWidth = str;
}
objetoElemento.prototype.setstrCamposWidth= setstrCamposWidth;

function getstrLinksUlContentServlet()
{
	return this.strLinksUlContentServlet;
}
objetoElemento.prototype.getstrLinksUlContentServlet= getstrLinksUlContentServlet;

function setstrLinksUlContentServlet(str)
{
	this.strLinksUlContentServlet = str;
}
objetoElemento.prototype.setstrLinksUlContentServlet= setstrLinksUlContentServlet;

function getstrMetodosController()
{
	return this.strMetodosController;
}
objetoElemento.prototype.getstrMetodosController= getstrMetodosController;

function setstrMetodosController(str)
{
	this.strMetodosController = str;
}
objetoElemento.prototype.setstrMetodosController= setstrMetodosController;

function getstrLinksUpdateServlet()
{
	return this.strLinksUpdateServlet;
}
objetoElemento.prototype.getstrLinksUpdateServlet= getstrLinksUpdateServlet;

function setstrLinksUpdateServlet(str)
{
	this.strLinksUpdateServlet = str;
}
objetoElemento.prototype.setstrLinksUpdateServlet= setstrLinksUpdateServlet;

function getstrEsOrdenable()
{
	return this.strEsOrdenable;
}
objetoElemento.prototype.getstrEsOrdenable= getstrEsOrdenable;

function setstrEsOrdenable(str)
{
	this.strEsOrdenable = str;
}
objetoElemento.prototype.setstrEsOrdenable= setstrEsOrdenable;

function getstrEventos()
{
	return this.strEventos;
}
objetoElemento.prototype.getstrEventos= getstrEventos;

function setstrEventos(str)
{
	this.strEventos = str;
}
objetoElemento.prototype.setstrEventos= setstrEventos;

function getstrValidarColumnasGrid()
{
	return this.strValidarColumnasGrid;
}
objetoElemento.prototype.getstrValidarColumnasGrid= getstrValidarColumnasGrid;

function setstrValidarColumnasGrid(str)
{
	this.strValidarColumnasGrid = str;
}
objetoElemento.prototype.setstrValidarColumnasGrid= setstrValidarColumnasGrid;


function getstrFormCampos()
{
	return this.strFormCampos;
}
objetoElemento.prototype.getstrFormCampos= getstrFormCampos;

function setstrFormCampos(str)
{
	this.strFormCampos = str;
}
objetoElemento.prototype.setstrFormCampos= setstrFormCampos;

function getstrFormCamposOblig()
{
	return this.strFormCamposOblig;
}
objetoElemento.prototype.getstrFormCamposOblig= getstrFormCamposOblig;

function setstrFormCamposOblig(str)
{
	this.strFormCamposOblig = str;
}
objetoElemento.prototype.setstrFormCamposOblig= setstrFormCamposOblig;

function getstrFormTipoEditor()
{
	return this.strFormTipoEditor;
}
objetoElemento.prototype.getstrFormTipoEditor= getstrFormTipoEditor;

function setstrFormTipoEditor(str)
{
	this.strFormTipoEditor = str;
}
objetoElemento.prototype.setstrFormTipoEditor= setstrFormTipoEditor;

function getstrFormCamposDec()
{
	return this.strFormCamposDec;
}
objetoElemento.prototype.getstrFormCamposDec= getstrFormCamposDec;

function setstrFormCamposDec(str)
{
	this.strFormCamposDec = str;
}
objetoElemento.prototype.setstrFormCamposDec= setstrFormCamposDec;

function getstrFormCamposWidth()
{
	return this.strFormCamposWidth;
}
objetoElemento.prototype.getstrFormCamposWidth= getstrFormCamposWidth;

function setstrFormCamposWidth(str)
{
	this.strFormCamposWidth = str;
}
objetoElemento.prototype.setstrFormCamposWidth= setstrFormCamposWidth;

function getstrFormLinksUlContentServlet()
{
	return this.strFormLinksUlContentServlet;
}
objetoElemento.prototype.getstrFormLinksUlContentServlet= getstrFormLinksUlContentServlet;

function setstrFormLinksUlContentServlet(str)
{
	this.strFormLinksUlContentServlet = str;
}
objetoElemento.prototype.setstrFormLinksUlContentServlet= setstrFormLinksUlContentServlet;

function getstrFormLinksElementServlet()
{
	return this.strFormLinksElementServlet;
}
objetoElemento.prototype.getstrFormLinksElementServlet= getstrFormLinksElementServlet;

function setstrFormLinksElementServlet(str)
{
	this.strFormLinksElementServlet = str;
}
objetoElemento.prototype.setstrFormLinksElementServlet= setstrFormLinksElementServlet;

function getstrFormMetodosController()
{
	return this.strFormMetodosController;
}
objetoElemento.prototype.getstrFormMetodosController= getstrFormMetodosController;

function setstrFormMetodosController(str)
{
	this.strFormMetodosController = str;
}
objetoElemento.prototype.setstrFormMetodosController= setstrFormMetodosController;

function getstrValidarCamposForm()
{
	return this.strValidarCamposForm;
}
objetoElemento.prototype.getstrValidarCamposForm= getstrValidarCamposForm;

function setstrValidarCamposForm(str)
{
	this.strValidarCamposForm = str;
}
objetoElemento.prototype.setstrValidarCamposForm= setstrValidarCamposForm;


function getstrFormCabeceraLinks()
{
	return this.strFormCabeceraLinks;
}
objetoElemento.prototype.getstrFormCabeceraLinks= getstrFormCabeceraLinks;

function setstrFormCabeceraLinks(str)
{
	this.strFormCabeceraLinks = str;
}
objetoElemento.prototype.setstrFormCabeceraLinks= setstrFormCabeceraLinks;

function getstrFormCabeceraFunctions()
{
	return this.strFormCabeceraFunctions;
}
objetoElemento.prototype.getstrFormCabeceraFunctions= getstrFormCabeceraFunctions;

function setstrFormCabeceraFunctions(str)
{
	this.strFormCabeceraFunctions = str;
}
objetoElemento.prototype.setstrFormCabeceraFunctions= setstrFormCabeceraFunctions;

function getstrCabeceraLinks()
{
	return this.strCabeceraLinks;
}
objetoElemento.prototype.getstrCabeceraLinks= getstrCabeceraLinks;

function setstrCabeceraLinks(str)
{
	this.strCabeceraLinks = str;
}
objetoElemento.prototype.setstrCabeceraLinks= setstrCabeceraLinks;

function getstrCabeceraFunctions()
{
	return this.strCabeceraFunctions;
}
objetoElemento.prototype.getstrCabeceraFunctions= getstrCabeceraFunctions;

function setstrCabeceraFunctions(str)
{
	this.strCabeceraFunctions = str;
}
objetoElemento.prototype.setstrCabeceraFunctions= setstrCabeceraFunctions;

function getstrCabeceraIds()
{
	return this.strCabeceraIds;
}
objetoElemento.prototype.getstrCabeceraIds= getstrCabeceraIds;

function setstrCabeceraIds(str)
{
	this.strCabeceraIds = str;
}
objetoElemento.prototype.setstrCabeceraIds= setstrCabeceraIds;

function getstrLinkDetallePdfServlet()
{
	return this.strLinkDetallePdfServlet;
}
objetoElemento.prototype.getstrLinkDetallePdfServlet= getstrLinkDetallePdfServlet;

function setstrLinkDetallePdfServlet(str)
{
	this.strLinkDetallePdfServlet = str;
}
objetoElemento.prototype.setstrLinkDetallePdfServlet= setstrLinkDetallePdfServlet;

function getstrLinkDetallePdfServletDec()
{
	return this.strLinkDetallePdfServletDec;
}
objetoElemento.prototype.getstrLinkDetallePdfServletDec= getstrLinkDetallePdfServletDec;

function setstrLinkDetallePdfServletDec(str)
{
	this.strLinkDetallePdfServletDec = str;
}
objetoElemento.prototype.setstrLinkDetallePdfServletDec= setstrLinkDetallePdfServletDec;

function getstrLinkListaPdfServlet()
{
	return this.strLinkListaPdfServlet;
}
objetoElemento.prototype.getstrLinkListaPdfServlet= getstrLinkListaPdfServlet;

function setstrLinkListaPdfServlet(str)
{
	this.strLinkListaPdfServlet = str;
}
objetoElemento.prototype.setstrLinkListaPdfServlet= setstrLinkListaPdfServlet;

function getstrLinkListaPdfServletDec()
{
	return this.strLinkListaPdfServletDec;
}
objetoElemento.prototype.getstrLinkListaPdfServletDec= getstrLinkListaPdfServletDec;

function setstrLinkListaPdfServletDec(str)
{
	this.strLinkListaPdfServletDec = str;
}
objetoElemento.prototype.setstrLinkListaPdfServletDec= setstrLinkListaPdfServletDec;

function getstrFiltroLinks()
{
	return this.strFiltroLinks;
}
objetoElemento.prototype.getstrFiltroLinks= getstrFiltroLinks;

function setstrFiltroLinks(str)
{
	this.strFiltroLinks = str;
}
objetoElemento.prototype.setstrFiltroLinks= setstrFiltroLinks;

function getstrFiltroFunctions()
{
	return this.strFiltroFunctions;
}
objetoElemento.prototype.getstrFiltroFunctions= getstrFiltroFunctions;

function setstrFiltroFunctions(str)
{
	this.strFiltroFunctions = str;
}
objetoElemento.prototype.setstrFiltroFunctions= setstrFiltroFunctions;

function getstrSeparadorFecha()
{
	return this.strSeparadorFecha;
}
objetoElemento.prototype.getstrSeparadorFecha= getstrSeparadorFecha;

function setstrSeparadorFecha(str)
{
	this.strSeparadorFecha = str;
}
objetoElemento.prototype.setstrSeparadorFecha= setstrSeparadorFecha;

function getstrSeparadorHora()
{
	return this.strSeparadorHora;
}
objetoElemento.prototype.getstrSeparadorHora= getstrSeparadorHora;

function setstrSeparadorHora(str)
{
	this.strSeparadorHora = str;
}
objetoElemento.prototype.setstrSeparadorHora= setstrSeparadorHora;