\copy PROVINCIAS FROM 'provincias.txt' WITH DELIMITER ';'
\copy LOCALIDADES FROM 'localidadesSort.txt' WITH DELIMITER ';'
\copy TURNOS FROM 'turnos.txt' WITH DELIMITER ';'
\copy ESTADOSPRODUCCION FROM 'estadosproduccion.txt' WITH DELIMITER ';'